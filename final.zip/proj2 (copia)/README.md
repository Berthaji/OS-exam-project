# OS-exam-project
Code to recreate kind of a Space Invaders videogame, using C language with ncurses library..
